This function will take a numeric column from the data set and multiply all values by 2. Then a new column will be generated

add if/else statement for nonnumeric columns