# peterson.pkg
## An R package for processing and manipulating crabs data

And tyoe a few words about what your package does.
